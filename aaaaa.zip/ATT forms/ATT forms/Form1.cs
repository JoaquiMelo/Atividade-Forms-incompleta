using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;

namespace ATT_forms
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button2_Click(object sender, EventArgs e)
        {
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label20_Click(object sender, EventArgs e)
        {

        }

        private void button10_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            txtModelo.Text = "";
            txtPlaca.Text = "";
            txtCidade.Text = "";
            txtCor.Text = "";
            txtNome.Text = "";
            txtEndereco.Text = "";
            txtBairro.Text = "";
            txtComplemento.Text = "";
            txtCidade2.Text = "";
            txtRg.Text = "";
            txtCPF.Text = "";
            boxFabricante.SelectedIndex = -1;
            boxEstado3.SelectedIndex = -1;
            boxEstado.SelectedIndex = -1;
            boxAno.SelectedIndex = -1;


        }

        private void button6_Click(object sender, EventArgs e)
        {

        }
    }
}
