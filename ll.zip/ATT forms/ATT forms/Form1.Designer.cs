﻿namespace ATT_forms
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            groupBox1 = new GroupBox();
            button9 = new Button();
            button10 = new Button();
            pictureBoxVeiculo = new PictureBox();
            cbAno = new ComboBox();
            cbEstadoVeiculo = new ComboBox();
            cbFabricante = new ComboBox();
            txtCor = new TextBox();
            txtCidadeVeiculo = new TextBox();
            txtPlaca = new TextBox();
            txtModelo = new TextBox();
            label8 = new Label();
            label7 = new Label();
            label6 = new Label();
            label5 = new Label();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            groupBox2 = new GroupBox();
            button7 = new Button();
            button8 = new Button();
            pictureBoxProprietario = new PictureBox();
            chkPrimeiroVeiculo = new CheckBox();
            dtpNascimento = new DateTimePicker();
            cbEstado = new ComboBox();
            groupBox3 = new GroupBox();
            rbOutro = new RadioButton();
            rbMasculino = new RadioButton();
            rbFeminino = new RadioButton();
            txtCPF = new TextBox();
            txtRG = new TextBox();
            txtCidade = new TextBox();
            txtComplemento = new TextBox();
            txtBairro = new TextBox();
            txtEndereco = new TextBox();
            txtNome = new TextBox();
            label17 = new Label();
            label16 = new Label();
            label15 = new Label();
            label14 = new Label();
            label13 = new Label();
            label12 = new Label();
            label11 = new Label();
            label10 = new Label();
            label9 = new Label();
            button1 = new Button();
            label1 = new Label();
            button2 = new Button();
            button3 = new Button();
            button4 = new Button();
            button5 = new Button();
            button6 = new Button();
            groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBoxVeiculo).BeginInit();
            groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBoxProprietario).BeginInit();
            groupBox3.SuspendLayout();
            SuspendLayout();
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(button9);
            groupBox1.Controls.Add(button10);
            groupBox1.Controls.Add(pictureBoxVeiculo);
            groupBox1.Controls.Add(cbAno);
            groupBox1.Controls.Add(cbEstadoVeiculo);
            groupBox1.Controls.Add(cbFabricante);
            groupBox1.Controls.Add(txtCor);
            groupBox1.Controls.Add(txtCidadeVeiculo);
            groupBox1.Controls.Add(txtPlaca);
            groupBox1.Controls.Add(txtModelo);
            groupBox1.Controls.Add(label8);
            groupBox1.Controls.Add(label7);
            groupBox1.Controls.Add(label6);
            groupBox1.Controls.Add(label5);
            groupBox1.Controls.Add(label4);
            groupBox1.Controls.Add(label3);
            groupBox1.Controls.Add(label2);
            groupBox1.Location = new Point(12, 52);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(975, 256);
            groupBox1.TabIndex = 0;
            groupBox1.TabStop = false;
            groupBox1.Text = "Dado do Veiculo";
            // 
            // button9
            // 
            button9.Location = new Point(898, 180);
            button9.Name = "button9";
            button9.Size = new Size(71, 23);
            button9.TabIndex = 9;
            button9.Text = "Limpar";
            button9.UseVisualStyleBackColor = true;
            button9.Click += button9_Click;
            // 
            // button10
            // 
            button10.Location = new Point(804, 180);
            button10.Name = "button10";
            button10.Size = new Size(61, 23);
            button10.TabIndex = 10;
            button10.Text = "Carregar";
            button10.UseVisualStyleBackColor = true;
            button10.Click += button10_Click;
            // 
            // pictureBoxVeiculo
            // 
            pictureBoxVeiculo.BackColor = SystemColors.ButtonFace;
            pictureBoxVeiculo.Location = new Point(804, 25);
            pictureBoxVeiculo.Name = "pictureBoxVeiculo";
            pictureBoxVeiculo.Size = new Size(153, 148);
            pictureBoxVeiculo.TabIndex = 35;
            pictureBoxVeiculo.TabStop = false;
            // 
            // cbAno
            // 
            cbAno.FormattingEnabled = true;
            cbAno.Items.AddRange(new object[] { "1990", "1991", "1992", "1993", "1994", "1995", "1996", "1997", "1998", "1999", "2000", "2001", "2002", "2003", "2004", "2005", "2006", "2007", "2008", "2009", "2010", "2011", "2012", "2013", "2014", "2015", "2016", "2017", "2018", "2019", "2020", "2021", "2022", "2023", "2024", "2025", "2026" });
            cbAno.Location = new Point(41, 101);
            cbAno.Name = "cbAno";
            cbAno.Size = new Size(259, 23);
            cbAno.TabIndex = 34;
            cbAno.SelectedIndexChanged += boxAno_SelectedIndexChanged;
            // 
            // cbEstadoVeiculo
            // 
            cbEstadoVeiculo.FormattingEnabled = true;
            cbEstadoVeiculo.Items.AddRange(new object[] { "AC", "AL", "AP", "AM", "BA", "CE", "DF", "ES", "GO", "MA", "MT", "MS", "MG", "PA", "PB", "PR", "PE", "PI", "RJ", "RN", "RS", "RO", "RR", "SC", "SP", "SE", "TO" });
            cbEstadoVeiculo.Location = new Point(467, 180);
            cbEstadoVeiculo.Name = "cbEstadoVeiculo";
            cbEstadoVeiculo.Size = new Size(58, 23);
            cbEstadoVeiculo.TabIndex = 33;
            // 
            // cbFabricante
            // 
            cbFabricante.FormattingEnabled = true;
            cbFabricante.Items.AddRange(new object[] { "Toyota", "Volkswagen", "Ford", "Audi", "Honda", "Hyundai", "BMW", "Mercedes", "Nissan", "McLaren", "Fiat" });
            cbFabricante.Location = new Point(599, 36);
            cbFabricante.Name = "cbFabricante";
            cbFabricante.Size = new Size(121, 23);
            cbFabricante.TabIndex = 25;
            // 
            // txtCor
            // 
            txtCor.Location = new Point(476, 93);
            txtCor.Name = "txtCor";
            txtCor.Size = new Size(172, 23);
            txtCor.TabIndex = 24;
            // 
            // txtCidadeVeiculo
            // 
            txtCidadeVeiculo.Location = new Point(581, 180);
            txtCidadeVeiculo.Name = "txtCidadeVeiculo";
            txtCidadeVeiculo.Size = new Size(175, 23);
            txtCidadeVeiculo.TabIndex = 23;
            // 
            // txtPlaca
            // 
            txtPlaca.Location = new Point(71, 172);
            txtPlaca.Name = "txtPlaca";
            txtPlaca.Size = new Size(229, 23);
            txtPlaca.TabIndex = 22;
            // 
            // txtModelo
            // 
            txtModelo.Location = new Point(71, 25);
            txtModelo.Name = "txtModelo";
            txtModelo.Size = new Size(393, 23);
            txtModelo.TabIndex = 21;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(422, 180);
            label8.Name = "label8";
            label8.Size = new Size(42, 15);
            label8.TabIndex = 13;
            label8.Text = "Estado";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(531, 180);
            label7.Name = "label7";
            label7.Size = new Size(44, 15);
            label7.TabIndex = 12;
            label7.Text = "Cidade";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(434, 92);
            label6.Name = "label6";
            label6.Size = new Size(26, 15);
            label6.TabIndex = 11;
            label6.Text = "Cor";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(6, 180);
            label5.Name = "label5";
            label5.Size = new Size(35, 15);
            label5.TabIndex = 10;
            label5.Text = "Placa";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(6, 101);
            label4.Name = "label4";
            label4.Size = new Size(29, 15);
            label4.TabIndex = 9;
            label4.Text = "Ano";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(531, 39);
            label3.Name = "label3";
            label3.Size = new Size(62, 15);
            label3.TabIndex = 8;
            label3.Text = "Fabricante";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(6, 28);
            label2.Name = "label2";
            label2.Size = new Size(48, 15);
            label2.TabIndex = 7;
            label2.Text = "Modelo";
            label2.Click += label2_Click;
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(button7);
            groupBox2.Controls.Add(button8);
            groupBox2.Controls.Add(pictureBoxProprietario);
            groupBox2.Controls.Add(chkPrimeiroVeiculo);
            groupBox2.Controls.Add(dtpNascimento);
            groupBox2.Controls.Add(cbEstado);
            groupBox2.Controls.Add(groupBox3);
            groupBox2.Controls.Add(txtCPF);
            groupBox2.Controls.Add(txtRG);
            groupBox2.Controls.Add(txtCidade);
            groupBox2.Controls.Add(txtComplemento);
            groupBox2.Controls.Add(txtBairro);
            groupBox2.Controls.Add(txtEndereco);
            groupBox2.Controls.Add(txtNome);
            groupBox2.Controls.Add(label17);
            groupBox2.Controls.Add(label16);
            groupBox2.Controls.Add(label15);
            groupBox2.Controls.Add(label14);
            groupBox2.Controls.Add(label13);
            groupBox2.Controls.Add(label12);
            groupBox2.Controls.Add(label11);
            groupBox2.Controls.Add(label10);
            groupBox2.Controls.Add(label9);
            groupBox2.Location = new Point(12, 314);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(975, 228);
            groupBox2.TabIndex = 0;
            groupBox2.TabStop = false;
            groupBox2.Text = "Dado do Proprietario";
            // 
            // button7
            // 
            button7.Location = new Point(885, 174);
            button7.Name = "button7";
            button7.Size = new Size(84, 23);
            button7.TabIndex = 7;
            button7.Text = "Limpar";
            button7.UseVisualStyleBackColor = true;
            button7.Click += button7_Click;
            // 
            // button8
            // 
            button8.Location = new Point(814, 173);
            button8.Name = "button8";
            button8.Size = new Size(63, 24);
            button8.TabIndex = 8;
            button8.Text = "Carregar";
            button8.UseVisualStyleBackColor = true;
            button8.Click += button8_Click;
            // 
            // pictureBoxProprietario
            // 
            pictureBoxProprietario.BackColor = SystemColors.ButtonFace;
            pictureBoxProprietario.Location = new Point(814, 19);
            pictureBoxProprietario.Name = "pictureBoxProprietario";
            pictureBoxProprietario.Size = new Size(153, 148);
            pictureBoxProprietario.TabIndex = 36;
            pictureBoxProprietario.TabStop = false;
            // 
            // chkPrimeiroVeiculo
            // 
            chkPrimeiroVeiculo.AutoSize = true;
            chkPrimeiroVeiculo.Location = new Point(608, 78);
            chkPrimeiroVeiculo.Name = "chkPrimeiroVeiculo";
            chkPrimeiroVeiculo.Size = new Size(78, 19);
            chkPrimeiroVeiculo.TabIndex = 34;
            chkPrimeiroVeiculo.Text = "1° Veiculo";
            chkPrimeiroVeiculo.UseVisualStyleBackColor = true;
            // 
            // dtpNascimento
            // 
            dtpNascimento.Location = new Point(608, 37);
            dtpNascimento.Name = "dtpNascimento";
            dtpNascimento.Size = new Size(200, 23);
            dtpNascimento.TabIndex = 33;
            // 
            // cbEstado
            // 
            cbEstado.FormattingEnabled = true;
            cbEstado.Items.AddRange(new object[] { "DF", "ES", "GO", "MA", "MT", "MS", "MG", "PA", "PB", "PR", "PE", "PI", "RJ", "RN", "RS", "RO", "RR", "SC", "SP", "SE", "TO" });
            cbEstado.Location = new Point(454, 165);
            cbEstado.Name = "cbEstado";
            cbEstado.Size = new Size(58, 23);
            cbEstado.TabIndex = 26;
            // 
            // groupBox3
            // 
            groupBox3.Controls.Add(rbOutro);
            groupBox3.Controls.Add(rbMasculino);
            groupBox3.Controls.Add(rbFeminino);
            groupBox3.Location = new Point(599, 103);
            groupBox3.Name = "groupBox3";
            groupBox3.Size = new Size(158, 91);
            groupBox3.TabIndex = 32;
            groupBox3.TabStop = false;
            groupBox3.Text = "Sexo";
            // 
            // rbOutro
            // 
            rbOutro.AutoSize = true;
            rbOutro.Checked = true;
            rbOutro.Location = new Point(6, 67);
            rbOutro.Name = "rbOutro";
            rbOutro.Size = new Size(56, 19);
            rbOutro.TabIndex = 37;
            rbOutro.TabStop = true;
            rbOutro.Text = "Outro";
            rbOutro.UseVisualStyleBackColor = true;
            // 
            // rbMasculino
            // 
            rbMasculino.AutoSize = true;
            rbMasculino.Location = new Point(6, 42);
            rbMasculino.Name = "rbMasculino";
            rbMasculino.Size = new Size(80, 19);
            rbMasculino.TabIndex = 36;
            rbMasculino.Text = "Masculino";
            rbMasculino.UseVisualStyleBackColor = true;
            // 
            // rbFeminino
            // 
            rbFeminino.AutoSize = true;
            rbFeminino.Location = new Point(6, 22);
            rbFeminino.Name = "rbFeminino";
            rbFeminino.Size = new Size(75, 19);
            rbFeminino.TabIndex = 35;
            rbFeminino.Text = "Feminino";
            rbFeminino.UseVisualStyleBackColor = true;
            // 
            // txtCPF
            // 
            txtCPF.Location = new Point(456, 200);
            txtCPF.Name = "txtCPF";
            txtCPF.Size = new Size(166, 23);
            txtCPF.TabIndex = 31;
            // 
            // txtRG
            // 
            txtRG.Location = new Point(71, 205);
            txtRG.Name = "txtRG";
            txtRG.Size = new Size(329, 23);
            txtRG.TabIndex = 30;
            // 
            // txtCidade
            // 
            txtCidade.Location = new Point(71, 165);
            txtCidade.Name = "txtCidade";
            txtCidade.Size = new Size(329, 23);
            txtCidade.TabIndex = 29;
            // 
            // txtComplemento
            // 
            txtComplemento.Location = new Point(102, 131);
            txtComplemento.Name = "txtComplemento";
            txtComplemento.Size = new Size(456, 23);
            txtComplemento.TabIndex = 28;
            // 
            // txtBairro
            // 
            txtBairro.Location = new Point(54, 95);
            txtBairro.Name = "txtBairro";
            txtBairro.Size = new Size(504, 23);
            txtBairro.TabIndex = 27;
            // 
            // txtEndereco
            // 
            txtEndereco.Location = new Point(71, 51);
            txtEndereco.Name = "txtEndereco";
            txtEndereco.Size = new Size(487, 23);
            txtEndereco.TabIndex = 26;
            // 
            // txtNome
            // 
            txtNome.Location = new Point(56, 19);
            txtNome.Name = "txtNome";
            txtNome.Size = new Size(502, 23);
            txtNome.TabIndex = 25;
            // 
            // label17
            // 
            label17.AutoSize = true;
            label17.Location = new Point(626, 19);
            label17.Name = "label17";
            label17.Size = new Size(114, 15);
            label17.TabIndex = 16;
            label17.Text = "Data de Nascimento";
            // 
            // label16
            // 
            label16.AutoSize = true;
            label16.Location = new Point(6, 131);
            label16.Name = "label16";
            label16.Size = new Size(78, 15);
            label16.TabIndex = 15;
            label16.Text = "Complmento";
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.Location = new Point(10, 165);
            label15.Name = "label15";
            label15.Size = new Size(44, 15);
            label15.TabIndex = 14;
            label15.Text = "CIdade";
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Location = new Point(10, 200);
            label14.Name = "label14";
            label14.Size = new Size(22, 15);
            label14.TabIndex = 13;
            label14.Text = "RG";
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Location = new Point(406, 165);
            label13.Name = "label13";
            label13.Size = new Size(42, 15);
            label13.TabIndex = 12;
            label13.Text = "Estado";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Location = new Point(422, 200);
            label12.Name = "label12";
            label12.Size = new Size(28, 15);
            label12.TabIndex = 11;
            label12.Text = "CPF";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Location = new Point(10, 95);
            label11.Name = "label11";
            label11.Size = new Size(38, 15);
            label11.TabIndex = 10;
            label11.Text = "Bairro";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(10, 19);
            label10.Name = "label10";
            label10.Size = new Size(40, 15);
            label10.TabIndex = 9;
            label10.Text = "Nome";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(10, 51);
            label9.Name = "label9";
            label9.Size = new Size(56, 15);
            label9.TabIndex = 8;
            label9.Text = "Endereço";
            // 
            // button1
            // 
            button1.Location = new Point(879, 548);
            button1.Name = "button1";
            button1.Size = new Size(117, 35);
            button1.TabIndex = 0;
            button1.Text = "Sair";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // label1
            // 
            label1.Font = new Font("Microsoft Sans Serif", 24F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(183, 9);
            label1.Name = "label1";
            label1.Size = new Size(603, 48);
            label1.TabIndex = 1;
            label1.Text = "Cadastro Veiculo";
            label1.TextAlign = ContentAlignment.TopCenter;
            label1.Click += label1_Click;
            // 
            // button2
            // 
            button2.Location = new Point(723, 548);
            button2.Name = "button2";
            button2.Size = new Size(117, 35);
            button2.TabIndex = 2;
            button2.Text = "Limpar";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click_1;
            // 
            // button3
            // 
            button3.Location = new Point(543, 548);
            button3.Name = "button3";
            button3.Size = new Size(117, 35);
            button3.TabIndex = 3;
            button3.Text = "Excluir";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // button4
            // 
            button4.Location = new Point(367, 548);
            button4.Name = "button4";
            button4.Size = new Size(117, 35);
            button4.TabIndex = 4;
            button4.Text = "Consultar";
            button4.UseVisualStyleBackColor = true;
            button4.Click += button4_Click;
            // 
            // button5
            // 
            button5.Location = new Point(195, 548);
            button5.Name = "button5";
            button5.Size = new Size(117, 35);
            button5.TabIndex = 5;
            button5.Text = "Alterar";
            button5.UseVisualStyleBackColor = true;
            button5.Click += button5_Click;
            // 
            // button6
            // 
            button6.Location = new Point(12, 548);
            button6.Name = "button6";
            button6.Size = new Size(117, 35);
            button6.TabIndex = 6;
            button6.Text = "Cadastrar";
            button6.UseVisualStyleBackColor = true;
            button6.Click += button6_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveCaption;
            ClientSize = new Size(1008, 595);
            Controls.Add(button6);
            Controls.Add(button5);
            Controls.Add(button4);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(label1);
            Controls.Add(groupBox2);
            Controls.Add(groupBox1);
            Name = "Form1";
            Text = "Form1";
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBoxVeiculo).EndInit();
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBoxProprietario).EndInit();
            groupBox3.ResumeLayout(false);
            groupBox3.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private GroupBox groupBox1;
        private GroupBox groupBox2;
        private Label label1;
        private Button button1;
        private Button button2;
        private Button button3;
        private Button button4;
        private Button button5;
        private Button button6;
        private Label label8;
        private Label label7;
        private Label label6;
        private Label label5;
        private Label label4;
        private Label label3;
        private Label label2;
        private Label label16;
        private Label label15;
        private Label label14;
        private Label label13;
        private Label label12;
        private Label label11;
        private Label label10;
        private Label label9;
        private Label label17;
        private TextBox txtCor;
        private TextBox txtCidadeVeiculo;
        private TextBox txtPlaca;
        private TextBox txtModelo;
        private GroupBox groupBox3;
        private TextBox txtCPF;
        private TextBox txtRG;
        private TextBox txtCidade;
        private TextBox txtComplemento;
        private TextBox txtBairro;
        private TextBox txtEndereco;
        private TextBox txtNome;
        private ComboBox cbAno;
        private ComboBox cbEstadoVeiculo;
        private ComboBox cbFabricante;
        private CheckBox chkPrimeiroVeiculo;
        private DateTimePicker dtpNascimento;
        private ComboBox cbEstado;
        private RadioButton rbMasculino;
        private RadioButton rbFeminino;
        private Button button10;
        private PictureBox pictureBoxVeiculo;
        private PictureBox pictureBoxProprietario;
        private RadioButton rbOutro;
        private Button button7;
        private Button button8;
        private Button button9;
    }
}
