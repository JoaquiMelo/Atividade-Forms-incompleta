using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Rebar;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Window;

namespace ATT_forms
{
    public partial class Form1 : Form
    {
        // Classe para armazenar os dados
        public class CadastroVeiculo
        {
            public string Modelo { get; set; }
            public string Fabricante { get; set; }
            public string Ano { get; set; }
            public string Cor { get; set; }
            public string Placa { get; set; }
            public string EstadoVeiculo { get; set; }
            public string CidadeVeiculo { get; set; }

            public string Nome { get; set; }
            public string Endereco { get; set; }
            public string Bairro { get; set; }
            public string Complemento { get; set; }
            public string Cidade { get; set; }
            public string Estado { get; set; }
            public string RG { get; set; }
            public string CPF { get; set; }
            public string Sexo { get; set; }
            public DateTime DataNascimento { get; set; }
            public bool PrimeiroVeiculo { get; set; }
        }
        List<CadastroVeiculo> cadastros = new List<CadastroVeiculo>();

        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button2_Click(object sender, EventArgs e)
        {
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label20_Click(object sender, EventArgs e)
        {

        }

        private void button10_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog dialog = new OpenFileDialog())
            {
                dialog.Title = "Selecione uma imagem";
                dialog.Filter = "Arquivos de Imagem|*.jpg;*.jpeg;*.png;*.bmp;*.gif";
            }
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            txtModelo.Clear();
            cbFabricante.SelectedIndex = -1;
            cbAno.SelectedIndex = -1;
            txtCor.Clear();
            txtPlaca.Clear();
            cbEstadoVeiculo.SelectedIndex = -1;
            txtCidadeVeiculo.Clear();

            txtNome.Clear();
            txtEndereco.Clear();
            txtBairro.Clear();
            txtComplemento.Clear();
            txtCidade.Clear();
            cbEstado.SelectedIndex = -1;
            txtRG.Clear();
            txtCPF.Clear();


            dtpNascimento.Value = DateTime.Now;


            chkPrimeiroVeiculo.Checked = false;
            rbFeminino.Checked = false;
            rbMasculino.Checked = false;
            rbOutro.Checked = false;


            pictureBoxVeiculo.Image = null;
            pictureBoxProprietario.Image = null;
        }

        private void button6_Click(object sender, EventArgs e)
        {

            string modelo = txtModelo.Text;
            string fabricante = cbFabricante.Text;
            string ano = cbAno.Text;
            string cor = txtCor.Text;
            string placa = txtPlaca.Text;
            string estadoVeiculo = cbEstadoVeiculo.Text;
            string cidadeVeiculo = txtCidadeVeiculo.Text;

            string nome = txtNome.Text;
            string endereco = txtEndereco.Text;
            string bairro = txtBairro.Text;
            string complemento = txtComplemento.Text;
            string cidade = txtCidadeVeiculo.Text;
            string estado = cbEstado.Text;
            string rg = txtRG.Text;
            string cpf = txtCPF.Text;

            string sexo = rbFeminino.Checked ? "Feminino" :
                          rbMasculino.Checked ? "Masculino" :
                          rbOutro.Checked ? "Outro" : "Outro";
            DateTime nascimento = dtpNascimento.Value;
            bool primeiroVeiculo = chkPrimeiroVeiculo.Checked;


            MessageBox.Show($"Ve�culo: {modelo}, Propriet�rio: {nome}");
        }

        private void boxAno_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {

        }
        private void button4_Click(object sender, EventArgs e)
        {
            string cpfBusca = txtCPF.Text;

            var cadastro = cadastros.FirstOrDefault(c => c.CPF == cpfBusca);

            if (cadastro != null)
            {

                txtModelo.Text = cadastro.Modelo;
                cbFabricante.Text = cadastro.Fabricante;
                cbAno.Text = cadastro.Ano;
                txtCor.Text = cadastro.Cor;
                txtPlaca.Text = cadastro.Placa;
                cbEstadoVeiculo.Text = cadastro.EstadoVeiculo;
                txtCidadeVeiculo.Text = cadastro.CidadeVeiculo;

                txtNome.Text = cadastro.Nome;
                txtEndereco.Text = cadastro.Endereco;
                txtBairro.Text = cadastro.Bairro;
                txtComplemento.Text = cadastro.Complemento;
                txtCidade.Text = cadastro.Cidade;
                cbEstado.Text = cadastro.Estado;
                txtRG.Text = cadastro.RG;


                rbFeminino.Checked = cadastro.Sexo == "Feminino";
                rbMasculino.Checked = cadastro.Sexo == "Masculino";
                rbOutro.Checked = cadastro.Sexo == "Outro";

                dtpNascimento.Value = cadastro.DataNascimento;
                chkPrimeiroVeiculo.Checked = cadastro.PrimeiroVeiculo;
            }
            else
            {
                MessageBox.Show("Cadastro n�o encontrado para esse CPF.");
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string cpfBusca = txtCPF.Text;

            var cadastro = cadastros.FirstOrDefault(c => c.CPF == cpfBusca);

            if (cadastro != null)
            {
                
                DialogResult confirmacao = MessageBox.Show("Deseja realmente excluir este cadastro?",
                                                           "Confirma��o",
                                                           MessageBoxButtons.YesNo,
                                                           MessageBoxIcon.Warning);

                if (confirmacao == DialogResult.Yes)
                {
                    cadastros.Remove(cadastro);
                    MessageBox.Show("Cadastro exclu�do com sucesso.");
                }
            }
            else
            {
                MessageBox.Show("Cadastro n�o encontrado para esse CPF.");
            }
        }

        private void button9_Click(object sender, EventArgs e)
        {
            pictureBoxVeiculo.Image = null;
        }

        private void button7_Click(object sender, EventArgs e)
        {
            pictureBoxVeiculo.Image = null;
        }

        private void button8_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog dialog = new OpenFileDialog())
            {
                dialog.Title = "Selecione uma imagem";
                dialog.Filter = "Arquivos de Imagem|*.jpg;*.jpeg;*.png;*.bmp;*.gif";
            }
        }
    }

}
